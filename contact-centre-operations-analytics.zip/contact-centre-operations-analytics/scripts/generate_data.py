"""
generate_data.py
-----------------
Generates a SIMULATED contact-centre operations dataset for the
Contact Centre Operations Analytics portfolio project.

The data is fully synthetic. No real customer, agent, or employer data is used.
It is modelled to behave like real workforce-management (WFM) MI data:
weekly seasonality, queue-level differences, forecast-vs-actual variance,
and staffing-driven service levels (via Erlang C).

Output:
    data/contact_centre_operations.csv   (one row per day per queue)
    dashboard/dashboard_data.json        (aggregations the dashboard reads)

Run:
    python scripts/generate_data.py
"""

import json
import math
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd

SEED = 42
rng = np.random.default_rng(SEED)

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(HERE, "data")
DASH_DIR = os.path.join(HERE, "dashboard")

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------
N_DAYS = 91  # 13 weeks
END_DATE = date(2026, 6, 28)
START_DATE = END_DATE - timedelta(days=N_DAYS - 1)

SL_TARGET = 0.80                 # answer 80% of calls...
SL_THRESHOLD_SECONDS = 20        # ...within 20 seconds  (the "80/20" target)
WORKDAY_SECONDS = 8 * 3600       # shift length used to convert daily volume to load

# Queue (department) profiles: base daily volume + average handle time (sec)
QUEUES = {
    "Servicing":        {"base_vol": 1850, "aht": 295, "complexity": 0.9},
    "Payments":         {"base_vol": 1200, "aht": 240, "complexity": 0.8},
    "Complaints":       {"base_vol": 430,  "aht": 540, "complexity": 1.3},
    "Financial Crime":  {"base_vol": 310,  "aht": 610, "complexity": 1.4},
    "Back-Office":      {"base_vol": 760,  "aht": 420, "complexity": 1.1},
    "Collections":      {"base_vol": 540,  "aht": 360, "complexity": 1.0},
}

# Monday..Sunday multipliers (call centres peak early week, quiet weekends)
WEEKDAY_FACTOR = [1.18, 1.08, 1.00, 0.97, 0.92, 0.45, 0.30]


# ----------------------------------------------------------------------
# Erlang C  (capacity planning engine)
# ----------------------------------------------------------------------
def erlang_c_probability(agents: int, traffic_intensity: float) -> float:
    """Probability a call waits (Erlang C). traffic_intensity in Erlangs."""
    if agents <= traffic_intensity:
        return 1.0
    a = traffic_intensity
    n = agents
    # sum_{k=0}^{n-1} a^k / k!
    summation = sum(a ** k / math.factorial(k) for k in range(n))
    last = a ** n / math.factorial(n) * (n / (n - a))
    return last / (summation + last)


def service_level(agents: int, traffic_intensity: float, aht: float,
                  threshold: float) -> float:
    """Predicted service level given staffing (fraction answered in threshold)."""
    if agents <= traffic_intensity:
        return 0.0
    pw = erlang_c_probability(agents, traffic_intensity)
    return max(0.0, 1.0 - pw * math.exp(-(agents - traffic_intensity) * threshold / aht))


def required_agents(traffic_intensity: float, aht: float, threshold: float,
                    target_sl: float) -> int:
    """Smallest agent count that meets the target service level."""
    agents = max(1, math.floor(traffic_intensity) + 1)
    while service_level(agents, traffic_intensity, aht, threshold) < target_sl:
        agents += 1
        if agents > 1000:
            break
    return agents


# ----------------------------------------------------------------------
# Generate rows
# ----------------------------------------------------------------------
rows = []
for i in range(N_DAYS):
    d = START_DATE + timedelta(days=i)
    wd = d.weekday()
    # gentle upward trend across the quarter (volume +0.05% per day)
    trend = 1.0 + 0.0005 * i

    for q, p in QUEUES.items():
        # --- Forecast (what WFM planned) ---
        forecast_vol = p["base_vol"] * WEEKDAY_FACTOR[wd] * trend
        forecast_vol = int(round(forecast_vol * rng.normal(1.0, 0.015)))

        # --- Actual (what really happened) ---
        actual_vol = int(round(forecast_vol * rng.normal(1.0, 0.06)))
        actual_vol = max(0, actual_vol)

        aht = p["aht"] * rng.normal(1.0, 0.05)
        aht = float(round(aht, 1))

        # Required staffing for the actual volume (Erlang C)
        traffic = actual_vol * aht / WORKDAY_SECONDS  # Erlangs
        req_agents = required_agents(traffic, aht, SL_THRESHOLD_SECONDS, SL_TARGET)

        # Scheduled agents: planned from FORECAST, so under-forecast days get short-staffed
        plan_traffic = forecast_vol * aht / WORKDAY_SECONDS
        sched_agents = required_agents(plan_traffic, aht, SL_THRESHOLD_SECONDS, SL_TARGET)
        # real-world rostering noise (sickness, no-shows, over-rostering)
        sched_agents = max(1, sched_agents + int(rng.integers(-2, 2)))

        # Achieved service level given what was actually scheduled vs actual demand
        achieved_sl = service_level(sched_agents, traffic, aht, SL_THRESHOLD_SECONDS)
        achieved_sl = float(np.clip(achieved_sl * rng.normal(1.0, 0.02), 0, 0.999))

        # ASA grows sharply when understaffed
        if sched_agents > traffic:
            pw = erlang_c_probability(sched_agents, traffic)
            asa = pw * aht / (sched_agents - traffic)
        else:
            asa = aht * 1.5
        asa = float(round(min(asa, 600) * rng.normal(1.0, 0.05), 1))

        # Abandonment rises with ASA
        abandon_rate = float(np.clip(0.01 + asa / 1200, 0, 0.25))
        calls_abandoned = int(round(actual_vol * abandon_rate))
        calls_handled = actual_vol - calls_abandoned

        occupancy = float(np.clip(traffic / sched_agents * rng.normal(1.0, 0.03), 0.4, 0.98))
        adherence = float(np.clip(rng.normal(0.91, 0.04), 0.7, 0.99))
        shrinkage = float(np.clip(rng.normal(0.30, 0.04), 0.18, 0.45))
        fcr = float(np.clip(rng.normal(0.78, 0.05) - (p["complexity"] - 1) * 0.06, 0.5, 0.95))
        csat = float(np.clip(rng.normal(4.1, 0.3) - (1 - achieved_sl) * 0.8, 1, 5))
        qa = float(np.clip(rng.normal(0.88, 0.05), 0.6, 1.0))

        rows.append({
            "date": d.isoformat(),
            "weekday": d.strftime("%a"),
            "queue": q,
            "forecast_volume": forecast_vol,
            "actual_volume": actual_vol,
            "calls_handled": calls_handled,
            "calls_abandoned": calls_abandoned,
            "abandon_rate_pct": round(abandon_rate * 100, 2),
            "aht_seconds": round(aht, 1),
            "asa_seconds": round(asa, 1),
            "service_level_pct": round(achieved_sl * 100, 2),
            "sl_target_pct": int(SL_TARGET * 100),
            "agents_scheduled": sched_agents,
            "agents_required": req_agents,
            "occupancy_pct": round(occupancy * 100, 2),
            "adherence_pct": round(adherence * 100, 2),
            "shrinkage_pct": round(shrinkage * 100, 2),
            "fcr_pct": round(fcr * 100, 2),
            "csat_score": round(csat, 2),
            "qa_score_pct": round(qa * 100, 2),
        })

df = pd.DataFrame(rows)
os.makedirs(DATA_DIR, exist_ok=True)
csv_path = os.path.join(DATA_DIR, "contact_centre_operations.csv")
df.to_csv(csv_path, index=False)
print(f"Wrote {len(df):,} rows -> {csv_path}")


# ----------------------------------------------------------------------
# Build aggregations for the dashboard (inlined so it runs anywhere)
# ----------------------------------------------------------------------
def wavg(frame, value, weight):
    w = frame[weight]
    return float((frame[value] * w).sum() / w.sum()) if w.sum() else 0.0

# headline KPIs across the whole period
period = {
    "start": START_DATE.isoformat(),
    "end": END_DATE.isoformat(),
    "calls_handled": int(df["calls_handled"].sum()),
    "actual_volume": int(df["actual_volume"].sum()),
    "service_level_pct": round(wavg(df, "service_level_pct", "actual_volume"), 1),
    "sl_target_pct": int(SL_TARGET * 100),
    "aht_seconds": round(wavg(df, "aht_seconds", "actual_volume"), 0),
    "asa_seconds": round(wavg(df, "asa_seconds", "actual_volume"), 0),
    "occupancy_pct": round(wavg(df, "occupancy_pct", "actual_volume"), 1),
    "shrinkage_pct": round(df["shrinkage_pct"].mean(), 1),
    "adherence_pct": round(df["adherence_pct"].mean(), 1),
    "fcr_pct": round(wavg(df, "fcr_pct", "actual_volume"), 1),
    "abandon_rate_pct": round(wavg(df, "abandon_rate_pct", "actual_volume"), 1),
    "csat_score": round(wavg(df, "csat_score", "actual_volume"), 2),
}
# forecast accuracy = 1 - MAPE on daily totals
daily = df.groupby("date", as_index=False).agg(
    forecast_volume=("forecast_volume", "sum"),
    actual_volume=("actual_volume", "sum"),
    calls_handled=("calls_handled", "sum"),
)
daily["sl"] = df.groupby("date").apply(
    lambda g: (g["service_level_pct"] * g["actual_volume"]).sum() / g["actual_volume"].sum(),
    include_groups=False,
).values
daily["aht"] = df.groupby("date").apply(
    lambda g: (g["aht_seconds"] * g["actual_volume"]).sum() / g["actual_volume"].sum(),
    include_groups=False,
).values
daily["asa"] = df.groupby("date").apply(
    lambda g: (g["asa_seconds"] * g["actual_volume"]).sum() / g["actual_volume"].sum(),
    include_groups=False,
).values
daily["occupancy"] = df.groupby("date")["occupancy_pct"].mean().values
daily["shrinkage"] = df.groupby("date")["shrinkage_pct"].mean().values
daily["required"] = df.groupby("date")["agents_required"].sum().values
daily["scheduled"] = df.groupby("date")["agents_scheduled"].sum().values

mape = float((abs(daily["forecast_volume"] - daily["actual_volume"]) / daily["actual_volume"]).mean())
period["forecast_accuracy_pct"] = round((1 - mape) * 100, 1)

# per-queue summary
by_queue = []
for q, g in df.groupby("queue"):
    by_queue.append({
        "queue": q,
        "actual_volume": int(g["actual_volume"].sum()),
        "service_level_pct": round(wavg(g, "service_level_pct", "actual_volume"), 1),
        "aht_seconds": round(wavg(g, "aht_seconds", "actual_volume"), 0),
        "asa_seconds": round(wavg(g, "asa_seconds", "actual_volume"), 0),
        "fcr_pct": round(wavg(g, "fcr_pct", "actual_volume"), 1),
        "shrinkage_pct": round(g["shrinkage_pct"].mean(), 1),
    })
by_queue.sort(key=lambda x: x["actual_volume"], reverse=True)

# per-queue daily series (powers the dashboard filter)
daily_by_queue = {}
for q, g in df.groupby("queue"):
    g = g.sort_values("date")
    daily_by_queue[q] = [
        {
            "date": r["date"],
            "forecast": int(r["forecast_volume"]),
            "actual": int(r["actual_volume"]),
            "sl": round(float(r["service_level_pct"]), 1),
            "aht": round(float(r["aht_seconds"]), 0),
            "asa": round(float(r["asa_seconds"]), 0),
            "occupancy": round(float(r["occupancy_pct"]), 1),
            "shrinkage": round(float(r["shrinkage_pct"]), 1),
            "required": int(r["agents_required"]),
            "scheduled": int(r["agents_scheduled"]),
        }
        for _, r in g.iterrows()
    ]

dashboard_data = {
    "meta": {
        "generated_from": "synthetic data (scripts/generate_data.py, seed=42)",
        "period": f"{START_DATE.isoformat()} to {END_DATE.isoformat()}",
        "rows": len(df),
        "queues": list(QUEUES.keys()),
    },
    "kpis": period,
    "daily_by_queue": daily_by_queue,
    "daily": [
        {
            "date": r["date"],
            "forecast": int(r["forecast_volume"]),
            "actual": int(r["actual_volume"]),
            "sl": round(float(r["sl"]), 1),
            "aht": round(float(r["aht"]), 0),
            "asa": round(float(r["asa"]), 0),
            "occupancy": round(float(r["occupancy"]), 1),
            "shrinkage": round(float(r["shrinkage"]), 1),
            "required": int(r["required"]),
            "scheduled": int(r["scheduled"]),
        }
        for _, r in daily.iterrows()
    ],
    "by_queue": by_queue,
}

os.makedirs(DASH_DIR, exist_ok=True)
json_path = os.path.join(DASH_DIR, "dashboard_data.json")
with open(json_path, "w") as f:
    json.dump(dashboard_data, f, indent=2)
print(f"Wrote dashboard aggregations -> {json_path}")
print(f"Headline service level: {period['service_level_pct']}% (target {period['sl_target_pct']}%)")
print(f"Forecast accuracy: {period['forecast_accuracy_pct']}%")
