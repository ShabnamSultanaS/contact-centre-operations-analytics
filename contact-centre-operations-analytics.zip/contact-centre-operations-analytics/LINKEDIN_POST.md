# LinkedIn launch kit

Everything you need to post this project and get it seen. Personalise the brackets,
swap in your GitHub Pages link, and you're ready.

---

## 1) The main post (copy–paste, then tweak in your own voice)

> 📊 I built a Contact Centre Operations Analytics project — end to end.
>
> I wanted a portfolio piece that mirrors the real work of an Operations MI Analyst, so I built the whole pipeline: a simulated contact-centre dataset → SQL analysis → Erlang C capacity planning → an interactive dashboard.
>
> The brief: a centre running to an 80/20 service-level target across six queues (Servicing, Payments, Complaints, Financial Crime, Back-Office, Collections). Three questions every week — are we hitting SLA, why are we missing it, and how many agents do we need next week?
>
> What the data showed 👇
> • Service level came in at 74.7% vs the 80% target — every queue under target, worst in the complex queues (Complaints, Financial Crime).
> • Forecast accuracy was 97.7%, so the miss wasn't a forecasting problem.
> • The root cause was staffing: on breach days, rostered agents fell short of the Erlang C requirement. The fix is execution — aligning schedules to required headcount on peak days — not better forecasts.
>
> 🛠️ Built with: SQL (CTEs, window functions), Python (pandas, NumPy, Erlang C), and Chart.js for the dashboard. All data is 100% synthetic — no real customer or employer data.
>
> 🔗 Live dashboard + code in the comments. Feedback from fellow analysts very welcome.
>
> #DataAnalytics #MIReporting #WorkforceManagement #PowerBI #SQL #Python #ContactCentre #DataAnalyst #OpenToWork

**First comment (post the links here, not in the body — LinkedIn favours posts without outbound links in the main text):**

> 🔗 Live dashboard: [your GitHub Pages link]
> 💻 Code & write-up: [your GitHub repo link]

---

## 2) "Featured" section blurb (shorter, for your profile's Featured area)

> Contact Centre Operations Analytics & MI Dashboard — an end-to-end operations MI
> project: synthetic dataset, SQL analysis, Erlang C capacity planning, and an
> interactive dashboard tracking service level, AHT, ASA, occupancy, shrinkage and
> forecast accuracy across six queues. Built with SQL, Python and Chart.js.

---

## 3) Profile "Projects" section (LinkedIn → Add profile section → Projects)

- **Project name:** Contact Centre Operations Analytics & MI Dashboard
- **Description:**
  > End-to-end operations/WFM analytics project replicating the weekly workflow of an
  > Operations MI Analyst. Generated a realistic synthetic contact-centre dataset, wrote
  > SQL analysis (CTEs, window functions, MAPE, RAG service-level logic), built an Erlang C
  > forecasting and capacity-planning model in Python, and delivered an interactive dashboard
  > covering service level vs the 80/20 target, AHT, ASA, occupancy, shrinkage, FCR and
  > forecast accuracy across six queues. Identified that an 80% SLA target was missed (74.7%)
  > despite 97.7% forecast accuracy — a staffing-execution gap, not a forecasting one.
- **Associated with:** (leave blank — personal project)
- **Skills:** SQL · Python · Data Visualisation · Forecasting · Workforce Management · MI Reporting

---

## 4) Carousel outline (optional — turns the post into a high-reach document)

A LinkedIn document/carousel typically gets more reach than a plain post. Make these
into 7 simple slides (Canva, PowerPoint, or Google Slides — one screenshot per slide
where noted):

1. **Title** — "Contact Centre Operations Analytics — I built an MI pipeline end to end." Your name + role.
2. **The brief** — 80/20 SLA target, 6 queues, 3 weekly questions.
3. **The stack** — dataset → SQL → Erlang C forecasting → dashboard. (Simple flow diagram.)
4. **Finding 1** — Service level 74.7% vs 80%. Every queue under target. *(Screenshot: KPI cards + service-level chart.)*
5. **Finding 2** — Forecast accuracy 97.7% → it's not a forecasting problem. *(Screenshot: forecast vs actual chart.)*
6. **The root cause** — Scheduled agents < Erlang C requirement on breach days. *(Screenshot: required vs scheduled chart.)*
7. **Recommendation + CTA** — Align rosters to required headcount on peak days. "Code & live dashboard in the comments → [links]."

---

## 5) Posting tips for visibility

- **Post Tuesday–Thursday, ~8–9am Irish time** — highest engagement windows.
- **Put links in the first comment**, not the post body — the algorithm suppresses posts with outbound links in the main text.
- **Reply to every comment in the first hour** — early engagement drives reach.
- **Tag 2–3 relevant communities/people** sparingly (e.g. a data community, a former classmate), only where genuinely relevant.
- Keep **#OpenToWork** in the tags if you're actively searching, plus 3–5 topic hashtags (not 30).
- A week later, **reshare with a different angle** ("the one chart that explained the whole SLA miss") to reach people who missed it.
