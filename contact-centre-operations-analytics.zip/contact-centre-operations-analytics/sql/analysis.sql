-- =====================================================================
-- Contact Centre Operations Analytics  |  MI / SQL analysis
-- =====================================================================
-- Dataset : data/contact_centre_operations.csv  (one row per day per queue)
-- Dialect : ANSI SQL (tested mentally against PostgreSQL / SQL Server)
-- Purpose : the recurring questions an Operations MI Analyst answers each
--           week. Each query maps to a real operational decision.
-- ---------------------------------------------------------------------
-- Assumed table: ops  (load the CSV into a table named ops)
-- =====================================================================


-- 1. PERIOD SCORECARD ---------------------------------------------------
-- Volume-weighted headline KPIs for the whole period. This is the top
-- strip of any exec MI pack: are we hitting the 80/20 service-level target?
SELECT
    SUM(actual_volume)                                            AS calls_offered,
    SUM(calls_handled)                                            AS calls_handled,
    ROUND(100.0 * SUM(calls_abandoned) / SUM(actual_volume), 1)   AS abandon_rate_pct,
    ROUND(SUM(service_level_pct * actual_volume) / SUM(actual_volume), 1) AS service_level_pct,
    ROUND(SUM(aht_seconds       * actual_volume) / SUM(actual_volume), 0) AS aht_seconds,
    ROUND(SUM(asa_seconds       * actual_volume) / SUM(actual_volume), 0) AS asa_seconds,
    ROUND(AVG(occupancy_pct), 1)                                  AS occupancy_pct,
    ROUND(AVG(shrinkage_pct), 1)                                  AS shrinkage_pct,
    ROUND(AVG(adherence_pct), 1)                                  AS adherence_pct
FROM ops;


-- 2. SERVICE LEVEL vs TARGET, BY QUEUE ---------------------------------
-- Where is SLA being missed? Ranks queues by the gap to the 80% target so
-- operations can prioritise the worst performers. Uses a RAG flag.
SELECT
    queue,
    ROUND(SUM(service_level_pct * actual_volume) / SUM(actual_volume), 1) AS service_level_pct,
    MAX(sl_target_pct)                                                    AS target_pct,
    ROUND(SUM(service_level_pct * actual_volume) / SUM(actual_volume)
          - MAX(sl_target_pct), 1)                                       AS gap_to_target,
    CASE
        WHEN SUM(service_level_pct * actual_volume) / SUM(actual_volume) >= MAX(sl_target_pct)      THEN 'GREEN'
        WHEN SUM(service_level_pct * actual_volume) / SUM(actual_volume) >= MAX(sl_target_pct) - 5  THEN 'AMBER'
        ELSE 'RED'
    END                                                                  AS rag_status
FROM ops
GROUP BY queue
ORDER BY gap_to_target ASC;


-- 3. FORECAST ACCURACY (MAPE) ------------------------------------------
-- How good is planning? Mean Absolute Percentage Error on daily volume.
-- Low MAPE = trustworthy capacity plans. Reported overall and per queue.
SELECT
    queue,
    ROUND(100.0 * AVG(ABS(forecast_volume - actual_volume) * 1.0 / actual_volume), 2) AS mape_pct,
    ROUND(100.0 - 100.0 * AVG(ABS(forecast_volume - actual_volume) * 1.0 / actual_volume), 2) AS forecast_accuracy_pct
FROM ops
GROUP BY queue
ORDER BY mape_pct ASC;


-- 4. WEEKLY TREND with WINDOW FUNCTIONS --------------------------------
-- Week-over-week service level and volume, with a 7-day moving average of
-- ASA to smooth daily noise. Demonstrates window functions / framing.
WITH daily AS (
    SELECT
        date,
        SUM(actual_volume)                                            AS volume,
        SUM(service_level_pct * actual_volume) / SUM(actual_volume)   AS sl,
        SUM(asa_seconds       * actual_volume) / SUM(actual_volume)   AS asa
    FROM ops
    GROUP BY date
)
SELECT
    date,
    volume,
    ROUND(sl, 1)                                                      AS service_level_pct,
    ROUND(AVG(asa) OVER (ORDER BY date
                         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 1) AS asa_7d_moving_avg,
    ROUND(sl - LAG(sl, 7) OVER (ORDER BY date), 1)                     AS sl_wow_change
FROM daily
ORDER BY date;


-- 5. UNDERSTAFFING DIAGNOSIS -------------------------------------------
-- The root-cause query: on days we missed SLA, were we short of the
-- Erlang-C required headcount? Links the staffing gap to the SLA miss.
SELECT
    date,
    queue,
    agents_required,
    agents_scheduled,
    agents_scheduled - agents_required                                AS staffing_gap,
    service_level_pct,
    sl_target_pct
FROM ops
WHERE service_level_pct < sl_target_pct
  AND agents_scheduled < agents_required
ORDER BY staffing_gap ASC
LIMIT 20;


-- 6. DAY-OF-WEEK SEASONALITY -------------------------------------------
-- Feeds the roster: average demand and required staffing by weekday, so
-- planners know Mondays need the most cover.
SELECT
    weekday,
    ROUND(AVG(actual_volume), 0)   AS avg_volume,
    ROUND(AVG(agents_required), 0) AS avg_agents_required,
    ROUND(AVG(service_level_pct), 1) AS avg_service_level_pct
FROM ops
GROUP BY weekday
ORDER BY avg_volume DESC;


-- 7. QUEUE EFFICIENCY MATRIX -------------------------------------------
-- Quality vs effort: FCR and CSAT against AHT and complexity. Helps target
-- coaching and process fixes where handle time is high but FCR is low.
SELECT
    queue,
    ROUND(AVG(aht_seconds), 0)   AS avg_aht_seconds,
    ROUND(AVG(fcr_pct), 1)       AS avg_fcr_pct,
    ROUND(AVG(csat_score), 2)    AS avg_csat,
    ROUND(AVG(occupancy_pct), 1) AS avg_occupancy_pct
FROM ops
GROUP BY queue
ORDER BY avg_fcr_pct ASC;
