"""
forecasting.py
--------------
Demonstrates the planning half of an MI/WFM analyst's job:

1. Forecast next week's daily call volume per queue using a seasonal-naive
   baseline plus a 4-week moving average (transparent, explainable methods
   that operations teams trust).
2. Convert each forecast into a staffing requirement with Erlang C, so the
   output is an actionable capacity plan, not just a number.

Reads:  data/contact_centre_operations.csv
Writes: data/capacity_plan_next_week.csv

Run:
    python scripts/forecasting.py
"""

import math
import os
from datetime import timedelta

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(HERE, "data")

SL_TARGET = 0.80
SL_THRESHOLD_SECONDS = 20
WORKDAY_SECONDS = 8 * 3600


def erlang_c_probability(agents, traffic):
    if agents <= traffic:
        return 1.0
    summation = sum(traffic ** k / math.factorial(k) for k in range(agents))
    last = traffic ** agents / math.factorial(agents) * (agents / (agents - traffic))
    return last / (summation + last)


def service_level(agents, traffic, aht, threshold):
    if agents <= traffic:
        return 0.0
    pw = erlang_c_probability(agents, traffic)
    return max(0.0, 1.0 - pw * math.exp(-(agents - traffic) * threshold / aht))


def required_agents(traffic, aht, threshold=SL_THRESHOLD_SECONDS, target=SL_TARGET):
    agents = max(1, math.floor(traffic) + 1)
    while service_level(agents, traffic, aht, threshold) < target and agents < 1000:
        agents += 1
    return agents


def main():
    df = pd.read_csv(os.path.join(DATA_DIR, "contact_centre_operations.csv"),
                     parse_dates=["date"])
    df["dow"] = df["date"].dt.weekday

    plan_rows = []
    last_date = df["date"].max()

    for queue, g in df.groupby("queue"):
        # 4-week moving average of volume by day-of-week (captures weekly seasonality)
        recent = g[g["date"] > last_date - timedelta(days=28)]
        dow_profile = recent.groupby("dow")["actual_volume"].mean()
        aht_recent = recent["aht_seconds"].mean()

        for step in range(1, 8):  # next 7 days
            fdate = last_date + timedelta(days=step)
            dow = fdate.weekday()
            forecast_vol = float(dow_profile.get(dow, recent["actual_volume"].mean()))

            traffic = forecast_vol * aht_recent / WORKDAY_SECONDS
            agents = required_agents(traffic, aht_recent)
            predicted_sl = service_level(agents, traffic, aht_recent, SL_THRESHOLD_SECONDS)

            plan_rows.append({
                "date": fdate.date().isoformat(),
                "weekday": fdate.strftime("%a"),
                "queue": queue,
                "forecast_volume": int(round(forecast_vol)),
                "avg_handle_time_sec": round(aht_recent, 0),
                "traffic_erlangs": round(traffic, 1),
                "agents_required": agents,
                "predicted_service_level_pct": round(predicted_sl * 100, 1),
            })

    plan = pd.DataFrame(plan_rows)
    out = os.path.join(DATA_DIR, "capacity_plan_next_week.csv")
    plan.to_csv(out, index=False)

    print(f"Capacity plan written -> {out}\n")
    summary = (plan.groupby("weekday", sort=False)
                   .agg(forecast_volume=("forecast_volume", "sum"),
                        agents_required=("agents_required", "sum"))
                   .reindex(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]))
    print("Next-week staffing requirement (all queues):")
    print(summary.to_string())
    print(f"\nPeak day needs {int(summary['agents_required'].max())} agents; "
          f"quietest day needs {int(summary['agents_required'].min())}.")


if __name__ == "__main__":
    main()
